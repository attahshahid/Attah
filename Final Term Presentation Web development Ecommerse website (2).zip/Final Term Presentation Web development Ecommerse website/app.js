document.getElementById('btn').addEventListener('click', function(event) {
    var name = document.getElementById('Name').value;
    var email = document.getElementById('email').value;
    var phone = document.getElementById('pn').value;

    // Name validation
    if (!/^[a-zA-Z\s]*$/.test(name)) {
        alert('Sorry! Numbers and symbols are not allowed in the name field.');
        event.preventDefault(); // Prevent form submission
    }

    // Email validation
    if (!/^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/.test(email)) {
        alert('Email format is invalid.');
        event.preventDefault(); // Prevent form submission
    }

    // Phone number validation
    if (!/^\+\d{12}$/.test(phone)) {
        alert('Number format is invalid. Please enter in +923xxxxxxxxx format.');
        event.preventDefault(); // Prevent form submission
    }
});